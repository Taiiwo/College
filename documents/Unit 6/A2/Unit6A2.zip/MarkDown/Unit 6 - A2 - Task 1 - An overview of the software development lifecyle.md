Determination of Scope 
---------------------- 
This is basically what the customer wants or does not want. It can be 
obtained by asking the customer, and it is required because it is important 
to know what your customer needs before you start planning. 
 
Requirements gathering and specification 
---------------------------------------- 
Once you have what the customer wants in mind, we can start to gather the 
requirements that we would need to carry out the job. For example, if you 
need to make a website, you will need a webserver. 
 
Design 
------ 
Design is the planning of a job. It includes designing interfaces, as well 
as designing the structure of the back end of the project, so for the 
Website example: The design of the webpage, and also the design of the 
server backend, including database software as server side 
scripting/programming. 
 
Code 
---- 
Coding is the process in the process that requires you to physically 
fulfil the project. This process consists of, for insistance in our web 
development example, executing the design plan for both the front end and 
the back end. 
 
Test 
---- 
Testing or debugging is the process of using the system, as testing it for 
bugs, but also stress testing the system, for example: Attempting to DDOS a 
website to see whether the server is strong enough to withstand it's 
projected load. 
 
Implementation 
-------------- 
The implementations stage is that of finalizing the system, for example, 
making the website publicly accessible, buying domain names, and beginning 
to advertise, obviously; if those things are in your scope. 
 
Maintenance 
------------ 
This step is post-final, and is completely optional by the request of the 
customer. It is the process of making changes to the system as per your 
customers request. For example: Changing the look of a website, adding 
extra form fields, or adding entirely new elements to the original 
implementation. This, as a side note, is usually separately chargeable 
 

