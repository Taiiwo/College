Detailed Interface Diagrams
===========================

Login
-----
<img src="http://i.imgur.com/AsKp4TP.png" />

Register
--------
<img src="http://i.imgur.com/9tPva1T.png" />

Booking
-------
<img src="http://i.imgur.com/91ykhZo.jpg" />

