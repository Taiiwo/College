<center>My Tables and Charts</center>
=====================================

-------------------------------------

###Introduction
This document will explain the charts I have submitted in more detail, including their role in management decicions. Making management decicions needs to be made as easy as possible, and having a bunch of charts can be really helpful. Charts allow you to see data on a page, and identify where changes can be made in order to improve the business.

###Example of Possible Faults and Their Rectification
For the graphs containing information about numbers an percentages, you can see that a few types of incidents happen much more than others. It may then be necessary to invest in training for the IT staff to solve these problems faster, as they happen at a much higher rate.

In the charts I have submitted, you can see in graph 1 and 2, that there are considerably less complaints on a Friday. This probably becuase there is nobody working, for whatever reason. It would then perhaps be cost effective to hire less staff for work on Fridays.

In the graphs identifying the average length of time to complete a type of task, it may be possible to identify areas that the company may be able to offer training to improve the speed of completion of the more time costly tasks. This, however, is also dependant on how often that task occurs.

The final type of graph, the graph containing the type of faults fixed by technician, it may be possible to identify workers that are worse at particular types of task, and therefore it may be cost and time effective to only deploy that staff member on the specific types of task with which he excells.